# zAdmin
Admin menu
• OneSync Infinity friendly !
• Easy to use
• Free <3

Support Discord: https://discord.gg/6ATKeR2jSM
